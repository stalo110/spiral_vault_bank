<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | Citizen Trust Online Bank</title>
    <!-- Bootstrap -->
    <link href="main/assets/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- External Css -->
    <link rel="stylesheet" href="main/assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="main/assets/css/themify-icons.css" />
    <link rel="stylesheet" href="main/assets/css/magnific-popup.css" />
    <link rel="stylesheet" href="main/assets/css/owl.carousel.css" />

    <!-- Custom Css -->
    <link rel="stylesheet" type="text/css" href="main/css/main.css">
    
    <!--My Custom Css -->
    <link rel="stylesheet" type="text/css" href="main/css/mine.css">
    
    <!--My Custom Css -->
<a href="login.php"></a>
    <link rel="stylesheet" type="text/css" href="main/css/animate.min.css">

    <!-- Fonts -->
    <link href="main/https://fonts.googleapis.com/css?family=Lato:400,400i,700%7COpen+Sans" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Lato:400,700' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" type="text/css" href="main/https://fonts.googleapis.com/css?family=Expletus+Sans" />
    
   <!-- Favicon -->
    <!-- <link rel="shortcut icon" type="image/png" href="main/images/logooo.png"/> -->
    <link rel="stylesheet" href="main/css/animations.css">
    <link href="main/sweetalert-js/sweetalert.php" rel="stylesheet" type="text/css">
    <script type="text/javascript" src="main/sweetalert-js/sweetalert.min.php"></script>
    <script type="text/javascript" src="main/sweetalert-js/sweetalert-2.php"></script>

    <style type="text/css">

        .navbar-flexo .navbar-collapse{

            /* width: 100%; */
            /* height: 100px; */
            /* margin: auto; */
            background-color: white;
            /* background-image: url(img/bck.jpg); */
            /* background-repeat: no-repeat; */
            /* background-size: cover; */
            /* background-position: center; */







            /* background: red; */
            /* <img src="img/gettyimages-900792194-2048x2048.jpg" alt=""> !important; */
        }
        .navbar-flexo .navbar-collapse .navbar-nav li.dropdown::before{
            color: #336699 !important;
        }



    </style>


    <script type="text/javascript">
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}
</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="e0ea8af7-5025-42f4-8993-5adafa0117c4";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>


  </head>
  <body style=" overflow-x: hidden;">
<div class="container-fluid" style=" padding-right:0px; padding-left:0px;">

    <header style=" background-image: url(img/bck.jpg);
            background-repeat: no-repeat;
            background-size: cover;
            background-position: left;
             width: 100%; z-index: 1000;">
        <div  style="background: #264c67;" class="nav-top hidden-xs" >
            <div class="container">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="nav-top-social">
                            <ul>
                                <!-- <li style="color:white"><i class="fa fa-phone" style="color:white"></i>4157298629</li> -->
                                <li style="color:white"><a style="color:white !important" href="contact-us.php"><i style="color:white" class="fa fa-envelope" aria-hidden="true"></i> contact@citizentrustonlinebk.com</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 ">
                        <div class="nav-top-access">
                            <ul>
                                <li><a  href="login.php" style="color:white"><i class="fa fa-user" aria-hidden="true"></i>Login</a></li>

                                <li><a  href="register.php" style="color:white"><i class="fa fa-check-circle-o" aria-hidden="true"></i>Open Account</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <nav class="navbar navbar-flexo" id="coloo"  >
            <div class="" >
                <div class="navbar-header" >
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php" style="width:100px; height:10px;">

                    

                        <img src="img/nlog.png" style="width:100px; height:50px;" class="img-responsive" alt="Brand Logo">
                       
                        
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav navbar-right" >
                        <li class="dropdown" style="color: blue;">
                            <a href="#" style="color: white;">Banking & Loans</a>
                            <ul class="dropdown-menu">
                                <li><a href="Online-Banking.php">Online Banking</a></li>
                                <!-- <li><a href="Mobile-Banking.php">Mobile Banking</a></li> -->
                                <li><a href="Cards.php">Cards</a></li>
                                <li><a href="ATM.php">ATM</a></li>
                                <li><a href="Student_Loan_Refinance.php">Student Loan Refinance</a></li>

                               <!--  <li><a href="internet-banking.php">Internet Banking</a></li>
                                <li><a href="branch-banking.php">Branch Banking</a></li>
                                <li><a href="debit-card.php">Debit Card</a></li>
                                <li><a href="FCTeNS.php">FCTeNS</a></li>
                                <li><a href="e-statements.php">e-Statement</a></li> -->

                            </ul>
                        </li>
                        <li>
                            <a href="wealth-management.php" style="color: white;">Wealth Management</a>
                        </li>
                     
                        <li class="dropdown">
                            <a href="#" style="color: white;">Citizen Trust Online Bank</a>
                            <ul class="dropdown-menu">
                                <li><a  href="about.php">About Us</a></li>
                              <li><a  href="contact-us.php">Contact Us</a></li>
                                <li><a  href="careers.php">Careers</a></li>
                            </ul>
                        </li>
                        <li class="nav-search hidden-sm hidden-xs"><i class="fa fa-search" style="color: white;"></i></li>
             
                        <li><a class="hidden-lg hidden-md" href="register.php" style="color: white;">Register</a></li>
                        <li>
                            <a class="hidden-lg hidden-md" href="login.php" style="color: white;">Login</a></li>
                        <li style="padding: 0 !important">
                            <style>
                                .goog-te-menu-value {
                                    padding: 3px !important; 
                                }
                                
                                .goog-te-gadget-simple {
                                    background-color: #fff;
                                    border-left: 1px solid #d5d5d5;
                                    border-top: 1px solid #9b9b9b;
                                    border-bottom: 1px solid #e8e8e8;
                                    border-right: 1px solid #d5d5d5;
                                    font-size: 10pt;
                                    display: inline-block;
                                    padding-top: 1px;
                                    padding-bottom: 2px;
                                    border-radius: 10px;
                                    cursor: pointer;
                                    zoom: 1;
                                }
                               
                            </style>
                            
                        </li>
                    </ul>
                </div>
                
            </div>


            <div class="header-search">
                <div class="container">
                    <h3 class="search-title">Just type and press enter</h3>
                    <form id="searchForm" class="searchform" action="#" method="post">
                        <div class="form-group">
                            <input type="search" name="searchinput" placeholder="Search..." class="form-control" required>
                        </div>
                    </form>
                </div>
            </div>
        </nav>

    </header>	
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12 text-center my_heading">
            <h3 style=" color:white;">Sign In</h3>
        </div>
    </div>
</div>
     
     <!-- Image Content -->
     <div class="section-padding-top">
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-md-offset-2">
            <div>
              <h6 class="accordion-title">Online Realtime Balances and Transactions</h6> 
              <p>Please type your email and enter your password.              </p>
               
							                   <form action="scripts/userlogin.php" method="post" enctype="multipart/form-data">
						  <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2" style="margin-top: 10px;">
								<div class="input-group">
								  <span class="input-group-addon" id="basic-addon1">
								  	<i class="glyphicon glyphicon-user" style="color:#336699;"></i>								  </span>
								  <input type="text" name="username" class="form-control" placeholder="Enter Username" required aria-describedby="basic-addon1" id="ouser">
								</div>
							</div>
							
							<div class="col-xs-12 col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2" style="margin-top: 20px;">
								<div class="input-group">
								  <span class="input-group-addon" id="basic-addon1">
								  	<i class="glyphicon glyphicon-asterisk" style="color:#336699;"></i>								  </span>
								  <input type="password" name="pwd" class="form-control" placeholder="Enter Password" required aria-describedby="basic-addon1" id="opass">
								</div>
							</div>


                            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2" style="margin-top: 20px;">
                                <div class="input-group">
                                  <span class="input-group-addon" id="basic-addon1">
                                    <i class="glyphicon glyphicon-asterisk" style="color:#336699;"></i>                               </span>
                                  <input type="password" name="pin" class="form-control" placeholder="Enter Pin" required aria-describedby="basic-addon1" id="opass">
                                </div>
                            </div>


							
							<div class="col-xs-12 col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2" style="margin-top: 20px;">
								<button type="submit" name="login" class="button button-4x covered_but text_white" style="background-color:#336699;">Login</button>
							</div>
							</form>
                                                  

                            <div class="col-xs-12 col-sm-8 col-sm-offset-2 col-lg-8 col-lg-offset-2" style="margin-top: 5px;">
								<a href="register.php" >New Here? Enroll</a>							</div>
							
							<!-- Modal -->
						<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" data-keyboard="false" data-backdrop="static" aria-hidden="true">
						  <div class="modal-dialog">
						    <div class="modal-content">
						      <div class="modal-header" style="background-color:#336699;">
						        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
						        <h4 class="modal-title" id="myModalLabel" style="color:white;">Reset Password</h4>
						      </div>
						      <div class="modal-body">
						        <div class="row">
										<div class="col-md-12 col-sm-12" id="showData">
											Please enter your email below to reset password										</div>
										<div style="color:#336699; " class="col-md-12 col-sm-12" id="result">										</div>
										<div class="col-md-12 col-sm-12" id="showData">
											<div class="input-group">
											  <span class="input-group-addon" id="basic-addon1">
												<i class="glyphicon glyphicon-envelope" style="color:#336699;"></i>											  </span>
											  <input type="email" id="re_email" required name="email" class="form-control" placeholder="Enter Email Address" aria-describedby="basic-addon1">
											</div>
										</div>
								</div>
						      </div>
						      <div class="modal-footer">
						        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
								<button type="button" class="btn btn-primary" onClick="sendMail()">Send Mail</button>
						      </div>
						    </div>
						  </div>
						</div>
            </div>
          </div>
        </div>
      </div>
  </div>
<br>
    
  <!-- Footer -->

       






 <!-- Footer -->
 <div class="container-fluid" style="padding-left: 0px; background: rgb(21, 29, 40); padding-right: 0px;">
 <footer class="hazie_footer row">
      <div class="footer-widget-wrapper section-padding-80-55" style="background:url(images/slider/forex-bg.jpg); background-size: cover; background-repeat: no-repeat; padding-top: 40px;">


        <div class="container">
          <div class="row">
            <div class="text-center col-md-6 col-md-offset-3 col-sm-6 col-sm-offset-3 col-xs-12">
              <aside class="widget widget-content">
                <div class="widget-body">
                  <div class="my-link">
                    <ul >
                        <li ><a href="index.php" class="text_white">Home</a></li>
                      <li ><a href="about.php" class="text_white">About</a></li>
                      <li ><a href="contact-us.php" class="text_white">Contact</a></li>
                      <li ><a href="careers.php" class="text_white">Careers</a></li>
                    </ul>
                  </div>
                </div>
            
              </aside>
            </div>
            <div class="fix hidden-lg hidden-md"></div>  
          </div>
        </div>
      </div>
      <div class="footer-copyright">
        <div class="container">
          <div class="row">
            <div class="col-sm-6">
              <div class="copyright">
                <p> <a href="main/#">Citizen Trust Online Bank.</a> © All rights reserved.</p>
            
              </div>
            </div>
            <div class="col-sm-6">
              <div class="privacy text-right">
                <ul>
                       
					<!-- <li><a href="risk-disclosure.php">Risk Disclosure </a> | <a href="terms-and-conditions.php">Terms & Conditions </a> | <a href="privacy-policy.php">Privacy Policy</a></li> -->
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
</div>
    <!-- Footer End -->   
    
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="main/assets/js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="main/assets/js/bootstrap.min.js"></script>
    <script src="main/assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="main/assets/js/isotope.pkgd.min.js"></script>
    <script src="main/assets/js/jquery.countdown.min.js"></script>
    <script src="main/assets/js/jquery.countTo.js"></script>
    <script src="main/assets/js/jquery.magnific-popup.min.js"></script>
    <script src="main/assets/js/owl.carousel.min.js"></script>
    <script src="main/assets/js/visible.js"></script>
    <script src="main/assets/js/jquery.ajaxchimp.min.js"></script>
    <script src="main/js/custom.js"></script>
    <script src="main/js/main.js"></script>
    <!--<script src="main/js/mine.js"></script>-->
    <script src="main/js/wow.min.js"></script>

<!--<script src="//code.tidio.co/pnj6yomlfq7sopoxrhssufqsysdljkmj.js" async></script>-->

<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/60089bbea9a34e36b96e9699/1esgq0pi1';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->



  </body>
</html>
